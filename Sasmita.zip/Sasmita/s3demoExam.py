import boto3

# Let's use Amazon S3
s3 = boto3.resource('s3')

# Print out bucket names
for bucket in s3.buckets.all():
    print(bucket.name)

# Upload a new file
data = open('myfile.txt', 'rb')
s3.Bucket('mvsandbox1').put_object(Key='myfile.txt', Body=data)

#download a file
#s3client = boto3.client('s3')
#s3client.download_file('mvsandbox1', 'myfile.txt', './myfile_downloaded.txt')
